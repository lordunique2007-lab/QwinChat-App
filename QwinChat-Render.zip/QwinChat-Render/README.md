# ⚡ QwinChat v2.5 — Render Deployment Guide

**Privacy-first · AI-powered · Real-time messaging**

---

## 🗂️ Project Structure

```
QwinChat-Render/
├── backend/
│   ├── server.js          ← Express + Socket.IO server
│   ├── package.json
│   └── data.json          ← Auto-created (stores users)
├── frontend/
│   ├── index.html
│   ├── vite.config.js
│   ├── package.json
│   └── src/
│       ├── main.jsx
│       └── QwinChat.jsx   ← Full app (2500+ lines)
├── render.yaml            ← Render auto-deploy config
└── README.md
```

---

## 👑 Creator Credentials

| Field | Value |
|-------|-------|
| Phone 1 | +2347037422544 |
| Phone 2 | +2348083214219 |
| Password | Qwin2007 |
| QwinGPT Code | 2007 |

> Creator accounts get full panel access, crown badge 👑, and system controls.

---

## 🚀 DEPLOY TO RENDER — Step by Step

### STEP 1 — Create a GitHub Repository

1. Go to **https://github.com**
2. Click **"New repository"**
3. Name it: `qwinchat`
4. Set to **Public**
5. Click **"Create repository"**

### STEP 2 — Upload Your Files

**Option A — GitHub Website (easiest):**
1. Open your new repo
2. Click **"uploading an existing file"**
3. Drag and drop the entire `QwinChat-Render` folder
4. Click **"Commit changes"**

**Option B — Git Terminal:**
```bash
cd QwinChat-Render
git init
git add .
git commit -m "QwinChat v2.5 initial deploy"
git branch -M main
git remote add origin https://github.com/YOURUSERNAME/qwinchat.git
git push -u origin main
```

---

### STEP 3 — Deploy Backend on Render

1. Go to **https://render.com** → Sign up / Log in
2. Click **"New +"** → **"Web Service"**
3. Connect your GitHub → Select **`qwinchat`** repo
4. Fill in these settings:

| Setting | Value |
|---------|-------|
| **Name** | `qwinchat-backend` |
| **Root Directory** | `backend` |
| **Runtime** | `Node` |
| **Build Command** | `npm install` |
| **Start Command** | `npm start` |
| **Instance Type** | Free |

5. Click **"Create Web Service"**
6. Wait for it to deploy (2–3 minutes)
7. Copy your backend URL — it looks like:
   `https://qwinchat-backend.onrender.com`

✅ Test it: Visit `https://qwinchat-backend.onrender.com/api/health`
You should see: `{"status":"online","platform":"QwinChat v2.5",...}`

---

### STEP 4 — Deploy Frontend on Render

1. Click **"New +"** → **"Static Site"**
2. Connect same GitHub repo
3. Fill in these settings:

| Setting | Value |
|---------|-------|
| **Name** | `qwinchat` |
| **Root Directory** | `frontend` |
| **Build Command** | `npm install && npm run build` |
| **Publish Directory** | `dist` |

4. Click **"Create Static Site"**
5. Wait for build (2–4 minutes)
6. Your live URL: `https://qwinchat.onrender.com`

**🎉 That's it! QwinChat is LIVE!**

---

## 🔗 Connect Frontend to Backend (Optional real-time sync)

After deploying, update `frontend/src/QwinChat.jsx` — find this line near the top and add:

```js
const BACKEND_URL = "https://qwinchat-backend.onrender.com";
```

Then in your frontend, you can call:
```js
// Check live user count
const res = await fetch(`${BACKEND_URL}/api/stats`);
const data = await res.json();
console.log("Real users:", data.totalUsers);
```

---

## 👁️ Track Real Users Live

### From Creator Panel:
1. Log in with your creator number + `Qwin2007`
2. Tap **👑 Panel** → **👥 Users** tab
3. See every registered user with their name, phone, country, and join date

### From API (real-time):
Visit: `https://qwinchat-backend.onrender.com/api/stats`
```json
{
  "totalUsers": 14,
  "totalMessages": 284,
  "platform": "QwinChat v2.5"
}
```

---

## 📝 How Users Register & Login

### New Users:
1. Open QwinChat → **"Create New Account"**
2. Enter display name, @username, country (+234 default), phone, password
3. Get OTP (demo shows code in popup — real SMS needs Twilio)
4. Account created → saved permanently on backend

### Returning Users:
1. Open QwinChat → **"Sign In — I have an account"**
2. Enter phone + password → instantly logged in
3. All chats restored from local storage

---

## 🔐 Security Notes

| Feature | Status |
|---------|--------|
| Passwords stored | Plain text (demo) → Use bcrypt in production |
| Private chats | E2EE enforced — server never reads messages |
| Creator chat access | Architecturally blocked |
| Rate limiting | Backend enforced |
| CORS | Configured |

### For Production (upgrade later):
```bash
npm install bcryptjs jsonwebtoken mongoose
```
Then connect MongoDB Atlas for a proper database.

---

## 🌐 Share Your App

Once live, share this link with anyone:
```
https://qwinchat.onrender.com
```

Anyone who visits can create an account and start chatting.
You'll see them appear in your Creator Panel immediately.

---

## ⚠️ Free Tier Note

Render free tier **sleeps after 15 minutes** of inactivity.
First load after sleep takes ~30 seconds (spin-up time).

**To keep it always awake (free method):**
Use **UptimeRobot** (uptimerobot.com) → ping your URL every 10 minutes → free forever.

1. Sign up at uptimerobot.com
2. Add monitor → HTTP → `https://qwinchat-backend.onrender.com/api/health`
3. Every 10 min interval
4. Your app stays awake 24/7 ✅

---

## 📞 Support

Creator phones: **+2347037422544** | **+2348083214219**
Platform: QwinChat v2.5
Built for: Render.com deployment

---

*QwinChat — Private · Secure · AI-Powered · Real-time* ⚡
